package flashlight.flashlight;

import android.support.v7.app.AppCompatActivity;

import android.app.Activity;
import android.hardware.Camera;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ToggleButton;

    public class FlashLight extends Activity implements View.OnClickListener {

        // komponen
        ToggleButton tglbtnLampu;

        // objek
        @SuppressWarnings("deprecation")
        Camera kamera;

        @Override
        protected void onCreate(Bundle b) {
            super.onCreate(b);
            setContentView(R.layout.flash_light);

            // Initial komponen
            tglbtnLampu = (ToggleButton) findViewById(R.id.tglbtnLampu);
            tglbtnLampu.setOnClickListener(this);
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onClick(View v) {
            if (v == tglbtnLampu) {
                try {
                    if (tglbtnLampu.isChecked()) {
                        kamera = Camera.open();
                        Camera.Parameters params = kamera.getParameters();
                        params.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                        kamera.setParameters(params);
                        kamera.startPreview();
                    } else {
                        Camera.Parameters params = kamera.getParameters();
                        params.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                        kamera.setParameters(params);
                        kamera.stopPreview();
                        kamera.release();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("exceptionku", e.getMessage());
                }
            }
        }
    }